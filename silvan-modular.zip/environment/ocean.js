// A vast ocean filling the gap between the coastline cliffs and the painted
// mountain backdrop. This is the "sea/sun visual treatment... island —
// everything here is the universe you'll explore" item flagged as
// discussed-but-not-built in SILVAN_PLAN.md. It's also the actual
// Vanishing-of-Ethan-Carter trick: the mountains alone read as a wall you
// can't get past, but a hazy sea stretching out beyond them — visible,
// never reachable — is what sells "this small island is everything" far
// harder than the walkable land ever could on its own.
//
// Shows through because environment/terrain.js's getElevation() drops the
// seafloor below OCEAN_LEVEL past the coastline — same "flat plane,
// occluded by higher terrain" trick environment/lake.js already uses for
// the inland lake, just at the opposite scale. Reuses lake.js's general
// fresnel/glint shader language but as its own simpler material: no
// per-vertex depth grading or rain rings needed at this distance, just a
// slow distant swell, a horizon haze gradient, sun/moon glint, and —
// critically — fx/dynamic-fog.js so the horizon itself melts into the sky
// instead of hard-cutting to a flat fog color.

import * as THREE from 'three';
import { WORLD_SIZE, OCEAN_LEVEL } from '../core/world-state.js';
import { addDynamicFog } from '../fx/dynamic-fog.js';

export function createOcean(state) {
    // Comfortably past the mountain-boundary far ring (WORLD_SIZE * 0.62)
    // so the ocean's own outer edge is always hidden behind the mountains/
    // fog, never visible as a seam. A CircleGeometry rather than a square
    // plane so there's no straight edge to catch the eye at any angle.
    const radius = WORLD_SIZE * 0.72;
    const geo = new THREE.CircleGeometry(radius, 96, 0);
    geo.rotateX(-Math.PI / 2);

    state.oceanMaterial = new THREE.MeshStandardMaterial({
        color: 0x0a2230,
        roughness: 0.15,
        metalness: 0.05,
    });

    state.oceanMaterial.onBeforeCompile = (shader) => {
        shader.uniforms.uTime = { value: 0 };
        shader.uniforms.uSunDir = { value: new THREE.Vector3(0, 1, 0) };
        shader.uniforms.uMoonDir = { value: new THREE.Vector3(0, 1, 0) };
        shader.uniforms.uSunColor = { value: new THREE.Color(0xfff4d6) };
        shader.uniforms.uMoonColor = { value: new THREE.Color(0xaac4ff) };
        shader.uniforms.uSunStrength = { value: 0 };
        shader.uniforms.uMoonStrength = { value: 0 };
        shader.uniforms.uDeepColor = { value: new THREE.Color(0x061a24) };
        shader.uniforms.uHorizonColor = { value: new THREE.Color(0x4d7a8c) };
        state.oceanMaterial.userData.shader = shader;

        shader.vertexShader = shader.vertexShader.replace('#include <common>', `
            #include <common>
            uniform float uTime;
            varying vec3 vWorldPos;
            varying vec3 vViewDirW;
            varying vec3 vWaveNormal;
        `);
        shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `
            #include <begin_vertex>
            vWorldPos = (modelMatrix * vec4(position, 1.0)).xyz;
            vViewDirW = cameraPosition - vWorldPos;

            // Slow, big rolling swell — this is meant to be seen from a
            // clifftop at a distance, never walked on, so it's tuned much
            // slower and broader than the lake's chop (environment/lake.js).
            float a1 = 0.012, a2 = 0.009, sp1 = 0.35, sp2 = 0.27;
            float amp1 = 0.9, amp2 = 0.6;
            transformed.y += sin(position.x * a1 + uTime * sp1) * amp1
                            + cos(position.z * a2 - uTime * sp2) * amp2;
            float dHdx = amp1 * a1 * cos(position.x * a1 + uTime * sp1);
            float dHdz = -amp2 * a2 * sin(position.z * a2 - uTime * sp2);
            vWaveNormal = normalize(vec3(-dHdx, 1.0, -dHdz));
        `);

        shader.fragmentShader = shader.fragmentShader.replace('#include <common>', `
            #include <common>
            uniform float uTime;
            uniform vec3 uSunDir;
            uniform vec3 uMoonDir;
            uniform vec3 uSunColor;
            uniform vec3 uMoonColor;
            uniform float uSunStrength;
            uniform float uMoonStrength;
            uniform vec3 uDeepColor;
            uniform vec3 uHorizonColor;
            varying vec3 vWorldPos;
            varying vec3 vViewDirW;
            varying vec3 vWaveNormal;
        `);
        shader.fragmentShader = shader.fragmentShader.replace(
            'vec4 diffuseColor = vec4( diffuse, opacity );',
            `
            vec3 viewDirN = normalize(vViewDirW);
            vec3 waterNormal = normalize(vWaveNormal);

            // Distance haze toward a lighter horizon color — real open water
            // visibly lightens/desaturates with distance under atmosphere,
            // well before fx/dynamic-fog.js's own sky-blend takes over even
            // further out. Without this the sea reads as one flat dark color
            // right up to where the fog starts, which looks like a floor with
            // an edge rather than something that recedes into distance.
            float dist = length(vViewDirW);
            float haze = smoothstep(60.0, 700.0, dist);
            vec3 baseCol = mix(uDeepColor, uHorizonColor, haze);

            float fresnel = pow(1.0 - clamp(dot(waterNormal, viewDirN), 0.0, 1.0), 3.0);
            baseCol = mix(baseCol, uHorizonColor, fresnel * 0.6);

            vec3 reflected = reflect(-viewDirN, waterNormal);
            float sunGlint = min(pow(max(dot(reflected, uSunDir), 0.0), 90.0), 1.0) * uSunStrength;
            float moonGlint = min(pow(max(dot(reflected, uMoonDir), 0.0), 110.0), 1.0) * uMoonStrength;
            baseCol += uSunColor * sunGlint * 1.8;
            baseCol += uMoonColor * moonGlint * 1.3;

            vec4 diffuseColor = vec4(baseCol, opacity);
            `
        );
    };

    // Melts into the actual sky/mountain color at the horizon instead of
    // hard-cutting to flat fog — see fx/dynamic-fog.js. Chain-safe: wraps
    // the swell/glint hook above rather than replacing it. This is the
    // single biggest thing that sells "endless sea" over "big blue floor
    // with an edge".
    addDynamicFog(state.oceanMaterial, state.backgroundRenderTarget.texture);

    state.oceanMesh = new THREE.Mesh(geo, state.oceanMaterial);
    state.oceanMesh.position.y = OCEAN_LEVEL;
    state.scene.add(state.oceanMesh);
}